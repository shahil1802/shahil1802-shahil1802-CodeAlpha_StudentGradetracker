#!/bin/bash
echo "Compiling Java Program..."
javac StudentGradeTracker.java
if [ $? -ne 0 ]; then
    echo "Compilation failed."
    exit 1
fi
echo "Running Program..."
java StudentGradeTracker