# CodeAlpha_StudentGradeTracker

## Project: Student Grade Tracker (Java)

### Description:
A simple console-based Java program to input and manage student grades. The program:
- Stores student names and grades using an ArrayList
- Calculates average, highest, and lowest scores
- Displays a complete summary report

### Features:
- Add student grades
- View grade statistics
- User-friendly console menu

### Technologies:
- Java (Core)
- ArrayList
- Loops and conditionals
- Scanner for input

### How to Run:
1. Compile the code:
   ```
   javac StudentGradeTracker.java
   ```
2. Run the program:
   ```
   java StudentGradeTracker
   ```

### Author:
Shahil Singh – Java Programming Intern at CodeAlpha