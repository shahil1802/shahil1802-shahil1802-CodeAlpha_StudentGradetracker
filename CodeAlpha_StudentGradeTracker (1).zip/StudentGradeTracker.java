import java.util.ArrayList;
import java.util.Scanner;

class Student {
    String name;
    double grade;

    Student(String name, double grade) {
        this.name = name;
        this.grade = grade;
    }
}

public class StudentGradeTracker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();

        while (true) {
            System.out.println("\n--- Student Grade Tracker ---");
            System.out.println("1. Add Student Grade");
            System.out.println("2. Show Summary Report");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter student name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter student grade: ");
                    double grade = scanner.nextDouble();
                    students.add(new Student(name, grade));
                    System.out.println("Student added successfully.");
                    break;

                case 2:
                    if (students.isEmpty()) {
                        System.out.println("No student data available.");
                        break;
                    }

                    double total = 0;
                    double max = Double.MIN_VALUE;
                    double min = Double.MAX_VALUE;

                    System.out.println("\nStudent Grades:");
                    for (Student s : students) {
                        System.out.println(s.name + ": " + s.grade);
                        total += s.grade;
                        if (s.grade > max) max = s.grade;
                        if (s.grade < min) min = s.grade;
                    }

                    double average = total / students.size();

                    System.out.println("\n--- Summary Report ---");
                    System.out.printf("Average Grade: %.2f\n", average);
                    System.out.printf("Highest Grade: %.2f\n", max);
                    System.out.printf("Lowest Grade: %.2f\n", min);
                    break;

                case 3:
                    System.out.println("Thank you for using the Student Grade Tracker. Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option. Please choose 1, 2, or 3.");
            }
        }
    }
}